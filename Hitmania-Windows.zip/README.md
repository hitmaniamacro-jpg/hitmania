# Hitmania — Steal an Egg Fishing Macro

A Windows fishing macro for the Roblox game **Steal an Egg**. It watches your
screen, plays the fishing minigame for you, and optionally posts every catch to
a Discord webhook.

No Python, no installs — just download `Hitmania.exe` and run it.

---

## Quick start

1. **Download** `Hitmania.exe` and put it in its own folder, e.g.
   `Documents\Hitmania\`.
   *(Keep it somewhere permanent — the app saves your settings next to itself.)*
2. **Double-click** `Hitmania.exe`.
   - Windows may show **"Windows protected your PC"** the first time. Click
     **More info → Run anyway**. This is normal for any small app that isn't
     code-signed (see *SmartScreen* below).
3. Open Roblox **Steal an Egg** in **windowed** mode (not exclusive fullscreen).
4. In Hitmania, open the **Setup** tab and follow the numbered steps.
5. Press **START FISHING** on the **Fish** tab, then click the Roblox window so
   it has focus.

That's it. The app needs no console and no command prompt — the window *is* the
program.

---

## First-time setup (about 5 minutes)

Do these in order. Everything is saved automatically to `config.json` next to
the exe, so you only do it once.

| Step | What to do |
|---|---|
| **0 · Game window** | Press **Fit to game window**. This locks Roblox to a fixed position/size so your calibration can't drift. |
| **1 · Cast point** | In game, equip your rod and aim at the water. Press **F9** (or the button). |
| **2 · Minigame bar** | Play manually until the click-fast bar appears, hover the cursor on it, press **F7**. |
| **3 · Reward popup** | When a reward popup is on screen, hover it and press **F8**. *(Recommended — improves timing.)* |
| **4 · Discord** | *(Optional)* Paste a webhook URL and press **Test**. |
| **5 · Start** | Go to the **Fish** tab, press **START FISHING** (or **F6**), then focus Roblox. |

### Hotkeys (rebindable in Setup)

| Key | Action |
|---|---|
| **F6** | Start / stop the macro |
| **F7** | Capture the minigame bar template |
| **F8** | Capture the reward popup template |
| **F9** | Set the cast point to the cursor |

Global hotkeys need no extra software — they're built in.

---

## Where your settings live

Everything is written **next to `Hitmania.exe`**:

```
Hitmania/
├─ Hitmania.exe      <- the app
├─ config.json       <- your settings (created on first run)
├─ templates/        <- your captured bar/reward images
└─ macro.log         <- timestamped log of the last run
```

Move the whole folder to move your setup. Delete `config.json` and `templates/`
to reset to defaults.

> **Do not** put the exe in `Program Files` or another protected folder — Windows
> won't let it save your calibration there. Use Documents, Desktop, or similar.

---

## SmartScreen / antivirus

Because the app isn't code-signed, Windows shows a "protected your PC" prompt the
first time. Click **More info → Run anyway**.

Some antivirus tools may also flag it, because macros that simulate mouse and
keyboard input look similar to automation malware. This app is an **external
screen macro**: it takes screenshots and sends clicks/keys via the Windows API.
It does **not** inject code into Roblox or read the game's memory.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Nothing is detected although the bar is visible | Open **Setup**, tick **Live detection test**, and watch the confidence. Recapture a tighter template (**F7**) or lower the threshold slider. |
| A click happens too early and resets the cast | Leave **Blind click burst** off (it is off by default). Re-capture the bar template on the exact bar. |
| The game window moves and detection breaks | Press **Fit to game window** — it re-aligns all points automatically. |
| Catches aren't posted to Discord | Check the webhook URL and press **Test**. |
| The macro clicks while another window is focused | Keep **Only click while the game is focused** enabled (default). |
| A catch feels slow to be followed by the next cast | Press **Save log** on the Fish tab and check the timings in `macro.log`. |
| The window doesn't open at all | See `Startup error` dialog text; make sure the exe isn't in a read-only folder. |

---

## Disclaimer

Automating gameplay can violate **Roblox's Terms of Use** or the game's own
rules. Use it at your own discretion and at your own risk — ideally in private
servers. This project is provided as-is, with no warranty.

---

## For developers

Run from source:

```
py -m pip install -r requirements.txt
py main.py
```

Build the single-file Windows exe (console-free):

```
py -m pip install pyinstaller
py -m PyInstaller Hitmania.spec --noconfirm
# -> dist/Hitmania.exe
```

`Hitmania.spec` bundles the customtkinter theme assets and disables the console
(`console=False`). User data (`config.json`, `templates/`, `macro.log`) is
created next to the exe at runtime, never inside the bundle.
